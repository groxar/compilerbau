int main () {
  int i;
  int a,b;
  a = b = 1;
  i = (a == 1) || (b == 1);
  return i;
}

find test/tests/fail -name "*.c" -exec ./bin/dhbwcc {} \; 1>&2

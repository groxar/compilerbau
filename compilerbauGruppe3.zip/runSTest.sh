find test/tests/success -name "*.c" -exec ./bin/dhbwcc {} \;

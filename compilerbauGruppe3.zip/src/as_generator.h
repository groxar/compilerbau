#pragma once

int genAssembly( char const * const _file_name);

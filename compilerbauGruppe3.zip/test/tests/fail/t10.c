void main () {
	int a[10];

	return a;
}


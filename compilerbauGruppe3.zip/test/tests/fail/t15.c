int func (int i) {
  return i;
}

int main () {
  return func();
}

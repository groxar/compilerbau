void main () {
	int a[10];

	while (a) {
		return;
	}

	return;
}


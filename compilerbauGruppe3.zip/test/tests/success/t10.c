int main () {
  int i;
  i = 0;
  if (i) {
    i = 12;
  } 
  else 
  {
    if (!(i == 10)) {
      i = 0;
    }
  }
  return i;
}

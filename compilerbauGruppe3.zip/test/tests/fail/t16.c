int func ( int arr[10] ) {
  return arr[0];
}

int main () {
  int i;
  return func(i);
}

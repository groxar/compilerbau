void main () {
	int a[10];

	if (a) {
		return;
	}

	return;
}


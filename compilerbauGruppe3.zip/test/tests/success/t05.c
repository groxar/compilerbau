int i;
int main () {
  int i; 
}
int func () {
  int i;
}

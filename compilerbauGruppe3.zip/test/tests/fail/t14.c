void test () {
	return;
}

void main () {
	int a[10];
	int b;

	b = a[1] + test();
}


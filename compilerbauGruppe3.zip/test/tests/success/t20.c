
int a;
int func(int b, int c, int d);

int main()
{
    do{
        a=a+a;
    }while(a>21);
    //i=1/2*3+5+12-2%3>>2&2|2+i<<3;
    return a;
    func(2,3,4);
}

int func(int b, int c , int d)
{
    int asd;
}

int foo()
{
    int bsd;
    bsd=bsd+1;
}

int add (int i, int j) {
  return i+j;
}

int main () {
  return add(1,2);
}

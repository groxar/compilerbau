int g,g;


int main () {
  int i;
  i = 12;
  if (i == 12 || i == 13 || (i >= 15 && i <= 17)) {
    i = 0;
  }
  else
  {
    i = 1;
  }
  return i;
}

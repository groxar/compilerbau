int main () {
  int i, b, a;
  a = 12;
  b = 13;
  i = b = a + a + b + b * a;

  return i;
}

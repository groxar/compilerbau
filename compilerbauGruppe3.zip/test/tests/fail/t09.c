void main () {
	int a;

	return a;
}

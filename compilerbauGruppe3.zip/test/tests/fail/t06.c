int func;

void func () {}

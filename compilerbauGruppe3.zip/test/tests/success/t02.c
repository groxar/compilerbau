int print (int i);

int print (int i) {
  return 2*i;
}
